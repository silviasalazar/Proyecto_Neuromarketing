﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Interfaz
{
    public class bdneuromarketing
    {
        public static SqlConnection ObtenerConexion()
        {
            SqlConnection conexion = new SqlConnection("Data source =LAPTOP-NI3KPHQC;" +
                "Initial Catalog=LAPTOP-NI3KPHQC; Password= ");
            conexion.Open();
            return conexion;
        }
    }
}
