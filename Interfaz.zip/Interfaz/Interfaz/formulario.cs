﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaz
{
    public partial class formulario : Form
    {
        public formulario()
        {
            InitializeComponent();
        }
        int Edad = 0;
        string Sexo = "";
        string EstadoCivil = "";

        private void button1_Click(object sender, EventArgs e)
        {
            Form bienvenida = new FormBienvenida();
            bienvenida.Show();
            Visible = false;
        }

        private void btnatras_Click(object sender, EventArgs e)
        {
            Form form1 = new Form1();
            form1.Show();
            Visible = false;
           
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            Edad = (int)nudEdad.Value;

        }
        //groupbox sexo
        private void groupBox1_Enter(object sender, EventArgs e)
        {
            
            if(rbMujer.Checked)
            {
                Sexo= "Mujer";
            }
            else if (rbHombre.Checked)
            {
                Sexo = "Hombre";
            }
            else if(rbOtro.Checked)
            {
                Sexo = "Otro";
            }

        }

        private void gbEstadoCivil_Enter(object sender, EventArgs e)
        {
            if(rbSoltero.Checked)
            {
                EstadoCivil = "Soltero";
            }
            else if(rbCasado.Checked)
            {
                EstadoCivil = "Casado";

            }
            else if (rbDivorciado.Checked)
            {
                EstadoCivil = "Divorciado";
            }
        }
    }
}
