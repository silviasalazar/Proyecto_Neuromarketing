﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaz
{
    class bdDatos
    {
        public string NumeroUsuario { get; set; }
        public string Sexo { get; set; }
        public int Edad { get; set; }
        public string EstadoCivil{ get; set; }

        public bdDatos() { }
       
        public bdDatos(string NumeroUsuario, string Sexo, int Edad,string EstadoCivil)
        {
            this.NumeroUsuario = NumeroUsuario;
            this.Sexo = Sexo;
            this.Edad = Edad;
            this.EstadoCivil = EstadoCivil;

        }
    }
}
