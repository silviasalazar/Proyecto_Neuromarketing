﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Interfaz
{
    public class DatosSql
    {
       /* public static int Agregar(bdDatos pUsuario)
        {
            int retorno = 0;
            using(SqlConnection conexion=bdneuromarketing.ObtenerConexion())
            {
                SqlCommand Comando = new SqlCommand(string.Format("Insert Into bdDatos(NumeroUsuario,Sexo,Edad,EstadoCivil) values ('{0}','{1}','{2}','{3}')",
                   pUsuario.NumeroUsuario, pUsuario.Sexo, pUsuario.Edad, pUsuario.EstadoCivil), conexion);

                retorno = Comando.ExecuteNonQuery();
            }
            return retorno;
          
        }*/

    }
}
