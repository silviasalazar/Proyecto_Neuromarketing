﻿namespace Interfaz
{
    partial class formulario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.nudEdad = new System.Windows.Forms.NumericUpDown();
            this.btnsiguiente = new System.Windows.Forms.Button();
            this.rbMujer = new System.Windows.Forms.RadioButton();
            this.rbHombre = new System.Windows.Forms.RadioButton();
            this.rbOtro = new System.Windows.Forms.RadioButton();
            this.rbCasado = new System.Windows.Forms.RadioButton();
            this.rbDivorciado = new System.Windows.Forms.RadioButton();
            this.rbSoltero = new System.Windows.Forms.RadioButton();
            this.btnatras = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gbSexo = new System.Windows.Forms.GroupBox();
            this.gbEdad = new System.Windows.Forms.GroupBox();
            this.gbEstadoCivil = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudEdad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.gbSexo.SuspendLayout();
            this.gbEdad.SuspendLayout();
            this.gbEstadoCivil.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(223, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(354, 55);
            this.label4.TabIndex = 3;
            this.label4.Text = "FORMULARIO";
            // 
            // nudEdad
            // 
            this.nudEdad.Location = new System.Drawing.Point(17, 19);
            this.nudEdad.Name = "nudEdad";
            this.nudEdad.Size = new System.Drawing.Size(48, 20);
            this.nudEdad.TabIndex = 7;
            this.nudEdad.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // btnsiguiente
            // 
            this.btnsiguiente.Location = new System.Drawing.Point(561, 398);
            this.btnsiguiente.Name = "btnsiguiente";
            this.btnsiguiente.Size = new System.Drawing.Size(75, 23);
            this.btnsiguiente.TabIndex = 12;
            this.btnsiguiente.Text = "SIGUIENTE";
            this.btnsiguiente.UseVisualStyleBackColor = true;
            this.btnsiguiente.Click += new System.EventHandler(this.button1_Click);
            // 
            // rbMujer
            // 
            this.rbMujer.AutoSize = true;
            this.rbMujer.Location = new System.Drawing.Point(17, 19);
            this.rbMujer.Name = "rbMujer";
            this.rbMujer.Size = new System.Drawing.Size(67, 17);
            this.rbMujer.TabIndex = 13;
            this.rbMujer.TabStop = true;
            this.rbMujer.Text = "MUJER";
            this.rbMujer.UseVisualStyleBackColor = true;
            // 
            // rbHombre
            // 
            this.rbHombre.AutoSize = true;
            this.rbHombre.Location = new System.Drawing.Point(17, 42);
            this.rbHombre.Name = "rbHombre";
            this.rbHombre.Size = new System.Drawing.Size(78, 17);
            this.rbHombre.TabIndex = 14;
            this.rbHombre.TabStop = true;
            this.rbHombre.Text = "HOMBRE";
            this.rbHombre.UseVisualStyleBackColor = true;
            // 
            // rbOtro
            // 
            this.rbOtro.AutoSize = true;
            this.rbOtro.Location = new System.Drawing.Point(17, 65);
            this.rbOtro.Name = "rbOtro";
            this.rbOtro.Size = new System.Drawing.Size(60, 17);
            this.rbOtro.TabIndex = 15;
            this.rbOtro.TabStop = true;
            this.rbOtro.Text = "OTRO";
            this.rbOtro.UseVisualStyleBackColor = true;
            // 
            // rbCasado
            // 
            this.rbCasado.AutoSize = true;
            this.rbCasado.Location = new System.Drawing.Point(17, 42);
            this.rbCasado.Name = "rbCasado";
            this.rbCasado.Size = new System.Drawing.Size(75, 17);
            this.rbCasado.TabIndex = 16;
            this.rbCasado.TabStop = true;
            this.rbCasado.Text = "CASADO";
            this.rbCasado.UseVisualStyleBackColor = true;
            // 
            // rbDivorciado
            // 
            this.rbDivorciado.AutoSize = true;
            this.rbDivorciado.Location = new System.Drawing.Point(17, 65);
            this.rbDivorciado.Name = "rbDivorciado";
            this.rbDivorciado.Size = new System.Drawing.Size(102, 17);
            this.rbDivorciado.TabIndex = 17;
            this.rbDivorciado.TabStop = true;
            this.rbDivorciado.Text = "DIVORCIADO";
            this.rbDivorciado.UseVisualStyleBackColor = true;
            // 
            // rbSoltero
            // 
            this.rbSoltero.AutoSize = true;
            this.rbSoltero.Location = new System.Drawing.Point(17, 19);
            this.rbSoltero.Name = "rbSoltero";
            this.rbSoltero.Size = new System.Drawing.Size(83, 17);
            this.rbSoltero.TabIndex = 19;
            this.rbSoltero.TabStop = true;
            this.rbSoltero.Text = "SOLTERO";
            this.rbSoltero.UseVisualStyleBackColor = true;
            // 
            // btnatras
            // 
            this.btnatras.Location = new System.Drawing.Point(334, 398);
            this.btnatras.Name = "btnatras";
            this.btnatras.Size = new System.Drawing.Size(75, 23);
            this.btnatras.TabIndex = 20;
            this.btnatras.Text = "ATRAS";
            this.btnatras.UseVisualStyleBackColor = true;
            this.btnatras.Click += new System.EventHandler(this.btnatras_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Interfaz.Properties.Resources.neuromarketing;
            this.pictureBox2.Location = new System.Drawing.Point(-2, -1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(128, 452);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Interfaz.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(334, 116);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(302, 238);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // gbSexo
            // 
            this.gbSexo.Controls.Add(this.rbMujer);
            this.gbSexo.Controls.Add(this.rbHombre);
            this.gbSexo.Controls.Add(this.rbOtro);
            this.gbSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSexo.Location = new System.Drawing.Point(132, 105);
            this.gbSexo.Name = "gbSexo";
            this.gbSexo.Size = new System.Drawing.Size(185, 100);
            this.gbSexo.TabIndex = 23;
            this.gbSexo.TabStop = false;
            this.gbSexo.Text = "1. SELECCIONE SU SEXO";
            this.gbSexo.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // gbEdad
            // 
            this.gbEdad.Controls.Add(this.nudEdad);
            this.gbEdad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbEdad.Location = new System.Drawing.Point(132, 211);
            this.gbEdad.Name = "gbEdad";
            this.gbEdad.Size = new System.Drawing.Size(185, 68);
            this.gbEdad.TabIndex = 24;
            this.gbEdad.TabStop = false;
            this.gbEdad.Text = "2. SELECCIONE SU EDAD";
            // 
            // gbEstadoCivil
            // 
            this.gbEstadoCivil.Controls.Add(this.rbSoltero);
            this.gbEstadoCivil.Controls.Add(this.rbCasado);
            this.gbEstadoCivil.Controls.Add(this.rbDivorciado);
            this.gbEstadoCivil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbEstadoCivil.Location = new System.Drawing.Point(132, 285);
            this.gbEstadoCivil.Name = "gbEstadoCivil";
            this.gbEstadoCivil.Size = new System.Drawing.Size(185, 107);
            this.gbEstadoCivil.TabIndex = 25;
            this.gbEstadoCivil.TabStop = false;
            this.gbEstadoCivil.Text = "3. ESTADO CIVIL";
            this.gbEstadoCivil.Enter += new System.EventHandler(this.gbEstadoCivil_Enter);
            // 
            // formulario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(648, 450);
            this.Controls.Add(this.gbEstadoCivil);
            this.Controls.Add(this.gbEdad);
            this.Controls.Add(this.gbSexo);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnatras);
            this.Controls.Add(this.btnsiguiente);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "formulario";
            this.Text = "formulario";
            ((System.ComponentModel.ISupportInitialize)(this.nudEdad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.gbSexo.ResumeLayout(false);
            this.gbSexo.PerformLayout();
            this.gbEdad.ResumeLayout(false);
            this.gbEstadoCivil.ResumeLayout(false);
            this.gbEstadoCivil.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudEdad;
        private System.Windows.Forms.Button btnsiguiente;
        private System.Windows.Forms.RadioButton rbMujer;
        private System.Windows.Forms.RadioButton rbHombre;
        private System.Windows.Forms.RadioButton rbOtro;
        private System.Windows.Forms.RadioButton rbCasado;
        private System.Windows.Forms.RadioButton rbDivorciado;
        private System.Windows.Forms.RadioButton rbSoltero;
        private System.Windows.Forms.Button btnatras;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox gbSexo;
        private System.Windows.Forms.GroupBox gbEdad;
        private System.Windows.Forms.GroupBox gbEstadoCivil;
    }
}